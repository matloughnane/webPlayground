Parallax Scrolling
==================

### The source code which accompanies the parallax scrolling tutorial in Smashing Magazine, July 2011 


# INTRODUCTION: 
Welcome! And you are most welcome. These files accompany a tutorial in Smashing Magazine which explains the finer points of parallax scrolling. They will make most sense when read/used in conjunction with that article. I have used a couple of bits from the lovely HTML5 Boilerplate, but the rest is my own work. Feel free to hack it to shreds for your own purposes :)

Email me The Simpsons reference in the source code and you win a free tweet. Or something. Probably.

[Read the full tutorial over at smashingmagazine.com/](http://www.smashingmagazine.com/)


### License:
MIT License

Copyright (c) 2011 Richard Shepherd

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.